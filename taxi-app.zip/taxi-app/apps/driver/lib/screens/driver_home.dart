import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:taxi_core/taxi_core.dart';
import 'package:url_launcher/url_launcher.dart';

class DriverHome extends StatefulWidget {
  final DriverProfile initial;
  const DriverHome({super.key, required this.initial});
  @override
  State<DriverHome> createState() => _DriverHomeState();
}

class _DriverHomeState extends State<DriverHome> {
  final _map = MapController();
  late bool _online = widget.initial.online;
  LatLng? _me;
  Trip? _offer, _active;
  RiderInfo? _rider;
  String? _riderFor;
  int _left = 0;

  StreamSubscription<List<Trip>>? _offerSub, _tripSub;
  StreamSubscription<Position>? _posSub;
  Timer? _tick, _heartbeat;

  @override
  void initState() {
    super.initState();
    _offerSub = Api.offersStream().listen(_onOffers);
    _tripSub = Api.driverTripsStream().listen(_onTrips);
    _tick = Timer.periodic(const Duration(seconds: 1), (_) => _countdown());
    if (_online) _startTracking();
  }

  @override
  void dispose() {
    _offerSub?.cancel();
    _tripSub?.cancel();
    _posSub?.cancel();
    _tick?.cancel();
    _heartbeat?.cancel();
    super.dispose();
  }

  // ---------- online / location ----------
  Future<void> _toggle(bool v) async {
    try {
      if (v && await LocationHelper.current() == null) {
        _snack('فعّل الموقع أولاً');
        return;
      }
      await Api.setOnline(v);
      setState(() => _online = v);
      v ? _startTracking() : _stopTracking();
    } catch (_) {
      _snack('تعذّر تغيير الحالة');
    }
  }

  void _push(double lat, double lng) {
    final ll = LatLng(lat, lng);
    if (mounted) setState(() => _me = ll);
    Api.updateLocation(lat, lng).catchError((_) {});
  }

  void _startTracking() {
    LocationHelper.current().then((p) {
      if (p == null) return;
      _push(p.latitude, p.longitude);
      try {
        _map.move(LatLng(p.latitude, p.longitude), 15);
      } catch (_) {}
    });
    _posSub?.cancel();
    _posSub = LocationHelper.stream().listen((p) => _push(p.latitude, p.longitude));
    // Matching needs a fresh timestamp even when parked.
    _heartbeat?.cancel();
    _heartbeat = Timer.periodic(const Duration(seconds: 15), (_) {
      if (_me != null) _push(_me!.latitude, _me!.longitude);
    });
  }

  void _stopTracking() {
    _posSub?.cancel();
    _heartbeat?.cancel();
  }

  // ---------- offers ----------
  void _onOffers(List<Trip> trips) {
    final now = DateTime.now();
    final live = trips.where((t) => t.status == TripStatus.requested && t.offeredTo != null && (t.offerExpiresAt?.isAfter(now) ?? false));
    setState(() => _offer = live.isEmpty ? null : live.first);
    _countdown();
  }

  void _countdown() {
    final o = _offer;
    if (o == null) return;
    final left = o.offerExpiresAt!.difference(DateTime.now()).inSeconds;
    if (left <= 0) {
      Api.rejectOffer(o.id).catchError((_) {});
      if (mounted) setState(() => _offer = null);
    } else if (mounted) {
      setState(() => _left = left);
    }
  }

  Future<void> _accept() async {
    final o = _offer;
    if (o == null) return;
    try {
      await Api.acceptTrip(o.id);
      setState(() => _offer = null);
    } catch (_) {
      _snack('انتهت مهلة الطلب');
    }
  }

  Future<void> _reject() async {
    final o = _offer;
    if (o == null) return;
    setState(() => _offer = null);
    Api.rejectOffer(o.id).catchError((_) {});
  }

  // ---------- active trip ----------
  void _onTrips(List<Trip> trips) {
    final act = trips.where((t) => t.status.isActive && t.status != TripStatus.requested);
    final t = act.isEmpty ? null : act.first;
    setState(() => _active = t);
    if (t != null && _riderFor != t.id) {
      _riderFor = t.id;
      Api.riderInfo(t.id).then((r) {
        if (mounted) setState(() => _rider = r);
      });
    }
  }

  Future<void> _advance() async {
    final t = _active;
    if (t == null) return;
    final next = switch (t.status) {
      TripStatus.accepted => TripStatus.arrived,
      TripStatus.arrived => TripStatus.started,
      _ => TripStatus.completed,
    };
    try {
      await Api.setTripStatus(t.id, next);
      if (next == TripStatus.completed && mounted) {
        await showDialog<void>(
          context: context,
          barrierDismissible: false,
          builder: (ctx) => AlertDialog(
            title: const Text('انتهت الرحلة'),
            content: Text('حصّل ${t.estFare?.toStringAsFixed(0) ?? ''} ${AppConfig.currency} نقداً'),
            actions: [FilledButton(onPressed: () => Navigator.pop(ctx), child: const Text('تم التحصيل'))],
          ),
        );
        if (mounted) await showRatingDialog(context, t.id, title: 'قيّم الراكب');
        _riderFor = null;
        setState(() => _rider = null);
      }
    } catch (_) {
      _snack('تعذّر تحديث الرحلة');
    }
  }

  Future<void> _cancel() async {
    final t = _active;
    if (t == null) return;
    try {
      await Api.cancelTrip(t.id, reason: 'driver');
    } catch (_) {
      _snack('لا يمكن الإلغاء الآن');
    }
  }

  Future<void> _navigate(double lat, double lng) =>
      launchUrl(Uri.parse('https://www.google.com/maps/dir/?api=1&destination=$lat,$lng'), mode: LaunchMode.externalApplication);

  void _snack(String m) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  String _advanceLabel(TripStatus s) => switch (s) {
        TripStatus.accepted => 'وصلت إلى الراكب',
        TripStatus.arrived => 'بدء الرحلة',
        _ => 'إنهاء الرحلة',
      };

  // ---------- UI ----------
  @override
  Widget build(BuildContext context) {
    final start = _me ?? LatLng(AppConfig.defaultLat, AppConfig.defaultLng);
    final a = _active;
    return Scaffold(
      appBar: AppBar(title: const Text('لوحة السائق'), actions: [IconButton(icon: const Icon(Icons.logout), onPressed: Api.signOut)]),
      body: Stack(children: [
        FlutterMap(
          mapController: _map,
          options: MapOptions(initialCenter: start, initialZoom: 14),
          children: [
            TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'com.example.taxi_driver'),
            MarkerLayer(markers: [
              if (_me != null) Marker(point: _me!, width: 44, height: 44, child: const Icon(Icons.local_taxi, size: 36)),
              if (a != null) Marker(point: LatLng(a.pickupLat, a.pickupLng), width: 40, height: 40, child: const Icon(Icons.my_location, color: Colors.blue, size: 30)),
              if (a != null) Marker(point: LatLng(a.dropLat, a.dropLng), width: 40, height: 40, alignment: Alignment.topCenter, child: const Icon(Icons.location_on, color: Colors.red, size: 40)),
            ]),
          ],
        ),
        if (a == null && _offer == null)
          Positioned(
            top: 12, left: 12, right: 12,
            child: Card(
              child: SwitchListTile(
                title: Text(_online ? 'متصل: بانتظار الطلبات' : 'غير متصل'),
                value: _online,
                onChanged: _toggle,
              ),
            ),
          ),
        if (_offer != null) Positioned(left: 12, right: 12, bottom: 12, child: _offerCard(_offer!)),
        if (a != null) Positioned(left: 12, right: 12, bottom: 12, child: _tripCard(a)),
      ]),
    );
  }

  Widget _offerCard(Trip o) {
    final toPickup = _me == null ? null : LocationHelper.distanceM(_me!.latitude, _me!.longitude, o.pickupLat, o.pickupLng);
    return Card(
      color: Theme.of(context).colorScheme.primaryContainer,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text('طلب جديد ($_left)', textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          Text('الأجرة: ${o.estFare?.toStringAsFixed(0) ?? '-'} ${AppConfig.currency}', textAlign: TextAlign.center),
          Text(
            'المشوار: ${((o.estDistanceM ?? 0) / 1000).toStringAsFixed(1)} كم'
            '${toPickup == null ? '' : '  •  يبعد عنك ${(toPickup / 1000).toStringAsFixed(1)} كم'}',
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: OutlinedButton(onPressed: _reject, child: const Text('رفض'))),
            const SizedBox(width: 12),
            Expanded(child: FilledButton(onPressed: _accept, child: const Text('قبول'))),
          ]),
        ]),
      ),
    );
  }

  Widget _tripCard(Trip t) => Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text(t.status.labelAr, textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleLarge),
            if (_rider != null) ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const CircleAvatar(child: Icon(Icons.person)),
              title: Text(_rider!.name ?? 'الراكب'),
              subtitle: Text(_rider!.phone ?? '', textDirection: TextDirection.ltr),
            ),
            Text('الأجرة: ${t.estFare?.toStringAsFixed(0) ?? '-'} ${AppConfig.currency} (نقداً)', textAlign: TextAlign.center),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              icon: const Icon(Icons.navigation),
              label: Text(t.status == TripStatus.started ? 'الملاحة إلى الوجهة' : 'الملاحة إلى الراكب'),
              onPressed: () => t.status == TripStatus.started ? _navigate(t.dropLat, t.dropLng) : _navigate(t.pickupLat, t.pickupLng),
            ),
            const SizedBox(height: 8),
            FilledButton(onPressed: _advance, child: Text(_advanceLabel(t.status))),
            if (t.status != TripStatus.started) TextButton(onPressed: _cancel, child: const Text('إلغاء الرحلة')),
          ]),
        ),
      );
}
