import 'package:flutter/material.dart';
import 'package:taxi_core/taxi_core.dart';
import 'driver_home.dart';

/// Decides what a signed-in user sees: register as driver, wait for approval, or work.
class DriverRoot extends StatefulWidget {
  const DriverRoot({super.key});
  @override
  State<DriverRoot> createState() => _DriverRootState();
}

class _DriverRootState extends State<DriverRoot> {
  late Future<DriverProfile?> _future = Api.myDriver();

  void _reload() => setState(() => _future = Api.myDriver());

  @override
  Widget build(BuildContext context) => FutureBuilder<DriverProfile?>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Scaffold(body: Center(child: CircularProgressIndicator()));
          }
          final d = snap.data;
          if (d == null) return _RegisterScreen(onDone: _reload);
          if (!d.approved) return _PendingScreen(onRefresh: _reload);
          return DriverHome(initial: d);
        },
      );
}

class _PendingScreen extends StatelessWidget {
  final VoidCallback onRefresh;
  const _PendingScreen({required this.onRefresh});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('قيد المراجعة'), actions: [IconButton(icon: const Icon(Icons.logout), onPressed: Api.signOut)]),
        body: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.hourglass_top, size: 64),
            const SizedBox(height: 16),
            const Text('تم استلام طلبك. سنراجع بياناتك ونفعّل حسابك قريباً.', textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton(onPressed: onRefresh, child: const Text('تحديث الحالة')),
          ]),
        ),
      );
}

class _RegisterScreen extends StatefulWidget {
  final VoidCallback onDone;
  const _RegisterScreen({required this.onDone});
  @override
  State<_RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<_RegisterScreen> {
  final _name = TextEditingController(), _plate = TextEditingController(), _model = TextEditingController(), _color = TextEditingController();
  List<VehicleType> _types = [];
  int? _typeId;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    Api.vehicleTypes().then((t) {
      if (mounted) setState(() {
        _types = t;
        _typeId = t.isEmpty ? null : t.first.id;
      });
    });
  }

  Future<void> _submit() async {
    if (_typeId == null || _name.text.trim().isEmpty || _plate.text.trim().isEmpty) return;
    setState(() => _busy = true);
    try {
      await Api.setMyName(_name.text.trim());
      await Api.becomeDriver(_typeId!, _plate.text.trim(), _model.text.trim(), _color.text.trim());
      widget.onDone();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذّر إرسال الطلب')));
        setState(() => _busy = false);
      }
    }
  }

  Widget _field(TextEditingController c, String label) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextField(controller: c, decoration: InputDecoration(labelText: label, border: const OutlineInputBorder())),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('التسجيل كسائق'), actions: [IconButton(icon: const Icon(Icons.logout), onPressed: Api.signOut)]),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          _field(_name, 'الاسم الكامل'),
          DropdownButtonFormField<int>(
            value: _typeId,
            decoration: const InputDecoration(labelText: 'نوع السيارة', border: OutlineInputBorder()),
            items: [for (final t in _types) DropdownMenuItem(value: t.id, child: Text(t.name))],
            onChanged: (v) => setState(() => _typeId = v),
          ),
          const SizedBox(height: 12),
          _field(_plate, 'رقم اللوحة'),
          _field(_model, 'الطراز'),
          _field(_color, 'اللون'),
          FilledButton(onPressed: _busy ? null : _submit, child: Text(_busy ? '...' : 'إرسال الطلب')),
        ]),
      );
}
