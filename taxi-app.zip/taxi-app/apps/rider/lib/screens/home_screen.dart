import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:taxi_core/taxi_core.dart';
import 'history_screen.dart';
import 'trip_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _map = MapController();
  LatLng? _me, _dest;
  List<VehicleType> _types = [];
  int? _typeId;
  FareEstimate? _est;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    final results = await Future.wait([Api.vehicleTypes(), Api.activeRiderTrip(), Api.myName()]);
    if (!mounted) return;
    final types = results[0] as List<VehicleType>;
    setState(() {
      _types = types;
      _typeId = types.isEmpty ? null : types.first.id;
    });
    final active = results[1] as Trip?;
    if (active != null) {
      _openTrip(active.id);
    } else if ((results[2] as String?)?.trim().isEmpty ?? true) {
      _askName();
    }
    _locate();
  }

  Future<void> _askName() async {
    final c = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text('ما اسمك؟'),
        content: TextField(controller: c, decoration: const InputDecoration(hintText: 'الاسم')),
        actions: [FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('حفظ'))],
      ),
    );
    if (name != null && name.isNotEmpty) await Api.setMyName(name);
  }

  Future<void> _locate() async {
    final p = await LocationHelper.current();
    if (p == null || !mounted) return;
    final ll = LatLng(p.latitude, p.longitude);
    setState(() => _me = ll);
    try {
      _map.move(ll, 15);
    } catch (_) {}
    _estimate();
  }

  void _onTap(LatLng ll) {
    setState(() {
      _dest = ll;
      _est = null;
    });
    _estimate();
  }

  Future<void> _estimate() async {
    if (_me == null || _dest == null || _typeId == null) return;
    try {
      final e = await Api.estimate(_me!.latitude, _me!.longitude, _dest!.latitude, _dest!.longitude, _typeId!);
      if (mounted) setState(() => _est = e);
    } catch (_) {}
  }

  Future<void> _openTrip(String id) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => TripScreen(tripId: id)));
    if (mounted) setState(() {
      _dest = null;
      _est = null;
    });
  }

  Future<void> _request() async {
    if (_me == null || _dest == null || _typeId == null) return;
    setState(() => _busy = true);
    try {
      final id = await Api.requestTrip(
        plat: _me!.latitude, plng: _me!.longitude,
        dlat: _dest!.latitude, dlng: _dest!.longitude, vtype: _typeId!,
      );
      if (mounted) await _openTrip(id);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذّر إنشاء الطلب')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final start = _me ?? LatLng(AppConfig.defaultLat, AppConfig.defaultLng);
    return Scaffold(
      appBar: AppBar(
        title: Text(AppConfig.appName),
        actions: [
          IconButton(
            icon: const Icon(Icons.history),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const HistoryScreen())),
          ),
          IconButton(icon: const Icon(Icons.logout), onPressed: Api.signOut),
        ],
      ),
      body: Stack(children: [
        FlutterMap(
          mapController: _map,
          options: MapOptions(initialCenter: start, initialZoom: 14, onTap: (_, ll) => _onTap(ll)),
          children: [
            // OSM public tiles: fine for development. For production traffic use
            // your own tile server or a provider (see docs/SETUP.md).
            TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'com.example.taxi_rider'),
            MarkerLayer(markers: [
              if (_me != null) Marker(point: _me!, width: 40, height: 40, child: const Icon(Icons.my_location, color: Colors.blue, size: 32)),
              if (_dest != null) Marker(point: _dest!, width: 40, height: 40, alignment: Alignment.topCenter, child: const Icon(Icons.location_on, color: Colors.red, size: 40)),
            ]),
          ],
        ),
        Positioned(
          left: 12, right: 12, bottom: 12,
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: _dest == null
                  ? const Text('اضغط على الخريطة لتحديد وجهتك', textAlign: TextAlign.center)
                  : Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                      Wrap(spacing: 8, children: [
                        for (final t in _types)
                          ChoiceChip(
                            label: Text(t.name),
                            selected: _typeId == t.id,
                            onSelected: (_) {
                              setState(() {
                                _typeId = t.id;
                                _est = null;
                              });
                              _estimate();
                            },
                          ),
                      ]),
                      const SizedBox(height: 12),
                      Text(
                        _est == null
                            ? 'جاري حساب السعر...'
                            : '${_est!.fare.toStringAsFixed(0)} ${AppConfig.currency}  •  ${(_est!.distanceM / 1000).toStringAsFixed(1)} كم  •  ${(_est!.durationS / 60).ceil()} دقيقة',
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 12),
                      FilledButton(
                        onPressed: (_busy || _est == null || _me == null) ? null : _request,
                        child: Text(_busy ? '...' : 'اطلب الآن'),
                      ),
                      if (_me == null) const Padding(padding: EdgeInsets.only(top: 8), child: Text('فعّل الموقع ليتم تحديد نقطة الانطلاق', textAlign: TextAlign.center)),
                    ]),
            ),
          ),
        ),
      ]),
    );
  }
}
