import 'package:flutter/material.dart';
import 'package:taxi_core/taxi_core.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('رحلاتي')),
        body: FutureBuilder<List<Trip>>(
          future: Api.myTrips(),
          builder: (context, snap) {
            if (snap.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
            final trips = snap.data ?? [];
            if (trips.isEmpty) return const Center(child: Text('لا توجد رحلات بعد'));
            return ListView.separated(
              itemCount: trips.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) {
                final t = trips[i];
                final d = t.requestedAt;
                return ListTile(
                  leading: Icon(t.status == TripStatus.completed ? Icons.check_circle : Icons.cancel,
                      color: t.status == TripStatus.completed ? Colors.green : Colors.grey),
                  title: Text('${d.year}/${d.month}/${d.day}  ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}'),
                  subtitle: Text(t.status.labelAr),
                  trailing: Text(t.finalFare == null ? '-' : '${t.finalFare!.toStringAsFixed(0)} ${AppConfig.currency}'),
                );
              },
            );
          },
        ),
      );
}
