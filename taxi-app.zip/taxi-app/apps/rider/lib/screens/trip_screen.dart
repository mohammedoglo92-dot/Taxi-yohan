import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:taxi_core/taxi_core.dart';

/// Follows one trip live: searching > driver coming > in progress > done.
class TripScreen extends StatefulWidget {
  final String tripId;
  const TripScreen({super.key, required this.tripId});
  @override
  State<TripScreen> createState() => _TripScreenState();
}

class _TripScreenState extends State<TripScreen> {
  Trip? _trip;
  DriverInfo? _driver;
  LatLng? _driverPos;
  StreamSubscription<Trip>? _tripSub;
  StreamSubscription<DriverProfile>? _driverSub;
  bool _ratingShown = false;

  @override
  void initState() {
    super.initState();
    _tripSub = Api.tripStream(widget.tripId).listen(_onTrip);
  }

  void _onTrip(Trip t) {
    setState(() => _trip = t);
    if (t.driverId != null && _driverSub == null) {
      Api.driverInfo(t.id).then((d) {
        if (mounted) setState(() => _driver = d);
      });
      _driverSub = Api.driverStream(t.driverId!).listen((d) {
        if (d.lat != null && d.lng != null && mounted) setState(() => _driverPos = LatLng(d.lat!, d.lng!));
      });
    }
    if (t.status == TripStatus.completed && !_ratingShown) {
      _ratingShown = true;
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        if (!mounted) return;
        await showRatingDialog(context, t.id, title: 'قيّم السائق');
        if (mounted) Navigator.pop(context);
      });
    }
  }

  @override
  void dispose() {
    _tripSub?.cancel();
    _driverSub?.cancel();
    super.dispose();
  }

  Future<void> _cancel() async {
    try {
      await Api.cancelTrip(widget.tripId);
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('لا يمكن الإلغاء الآن')));
    }
  }

  String _statusText(Trip t) {
    if (t.status == TripStatus.cancelled) {
      return t.cancelReason == 'no_driver' ? 'لم نجد سائقاً قريباً، حاول مرة أخرى' : 'تم إلغاء الرحلة';
    }
    return t.status.labelAr;
  }

  @override
  Widget build(BuildContext context) {
    final t = _trip;
    if (t == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final pickup = LatLng(t.pickupLat, t.pickupLng);
    final drop = LatLng(t.dropLat, t.dropLng);
    final canCancel = t.status == TripStatus.requested || t.status == TripStatus.accepted || t.status == TripStatus.arrived;
    final over = t.status == TripStatus.cancelled;

    return Scaffold(
      appBar: AppBar(title: const Text('رحلتك'), automaticallyImplyLeading: over),
      body: Column(children: [
        Expanded(
          child: FlutterMap(
            options: MapOptions(initialCenter: pickup, initialZoom: 14),
            children: [
              TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'com.example.taxi_rider'),
              MarkerLayer(markers: [
                Marker(point: pickup, width: 40, height: 40, child: const Icon(Icons.my_location, color: Colors.blue, size: 30)),
                Marker(point: drop, width: 40, height: 40, alignment: Alignment.topCenter, child: const Icon(Icons.location_on, color: Colors.red, size: 40)),
                if (_driverPos != null) Marker(point: _driverPos!, width: 44, height: 44, child: const Icon(Icons.local_taxi, color: Colors.black, size: 36)),
              ]),
            ],
          ),
        ),
        Card(
          margin: const EdgeInsets.all(12),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Text(_statusText(t), textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleLarge),
              if (t.status == TripStatus.requested) const Padding(padding: EdgeInsets.only(top: 12), child: LinearProgressIndicator()),
              if (_driver != null && t.status != TripStatus.cancelled) ...[
                const Divider(height: 24),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const CircleAvatar(child: Icon(Icons.person)),
                  title: Text(_driver!.name ?? 'السائق'),
                  subtitle: Text('${_driver!.carColor ?? ''} ${_driver!.carModel ?? ''}  •  ${_driver!.plate ?? ''}'),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.star, color: Colors.amber, size: 18), Text(_driver!.rating.toStringAsFixed(1))]),
                ),
                if (_driver!.phone != null) Text('هاتف السائق: ${_driver!.phone}', textDirection: TextDirection.ltr, textAlign: TextAlign.center),
              ],
              if (t.estFare != null) Padding(
                padding: const EdgeInsets.only(top: 12),
                child: Text('الأجرة: ${t.estFare!.toStringAsFixed(0)} ${AppConfig.currency} (نقداً)', textAlign: TextAlign.center),
              ),
              if (canCancel) TextButton(onPressed: _cancel, child: const Text('إلغاء الرحلة')),
              if (over) FilledButton(onPressed: () => Navigator.pop(context), child: const Text('رجوع')),
            ]),
          ),
        ),
      ]),
    );
  }
}
