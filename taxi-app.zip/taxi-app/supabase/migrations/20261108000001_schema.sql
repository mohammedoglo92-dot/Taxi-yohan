-- =====================================================================
-- 001: schema
-- Tables, enums, generated geography columns, new-user trigger.
-- =====================================================================
create extension if not exists postgis with schema extensions;
set search_path to public, extensions;

create type user_role   as enum ('rider', 'driver', 'admin');
create type trip_status as enum ('requested','accepted','arrived','started','completed','cancelled');
create type pay_method  as enum ('cash', 'wallet');

create table profiles (
  id         uuid primary key references auth.users on delete cascade,
  role       user_role not null default 'rider',
  full_name  text,
  phone      text unique not null,
  created_at timestamptz not null default now()
);

create table vehicle_types (
  id        serial primary key,
  name      text not null,
  base_fare numeric not null,
  per_km    numeric not null,
  per_min   numeric not null,
  min_fare  numeric not null,
  active    boolean not null default true
);

create table drivers (
  id                  uuid primary key references profiles on delete cascade,
  approved            boolean not null default false,
  online              boolean not null default false,
  vehicle_type_id     int references vehicle_types,
  plate               text,
  car_model           text,
  car_color           text,
  lat                 double precision,
  lng                 double precision,
  geom                geography(point, 4326)
    generated always as (st_setsrid(st_makepoint(lng, lat), 4326)::geography) stored,
  location_updated_at timestamptz,
  rating_avg          numeric not null default 5,
  rating_count        int not null default 0
);
create index drivers_geom_idx on drivers using gist (geom);

create table trips (
  id               uuid primary key default gen_random_uuid(),
  rider_id         uuid not null references profiles,
  driver_id        uuid references drivers,
  vehicle_type_id  int references vehicle_types,
  status           trip_status not null default 'requested',
  pickup_lat       double precision not null,
  pickup_lng       double precision not null,
  pickup_address   text,
  drop_lat         double precision not null,
  drop_lng         double precision not null,
  drop_address     text,
  pickup_geom      geography(point, 4326)
    generated always as (st_setsrid(st_makepoint(pickup_lng, pickup_lat), 4326)::geography) stored,
  est_distance_m   int,
  est_duration_s   int,
  est_fare         numeric,
  final_fare       numeric,
  pay_method       pay_method not null default 'cash',
  offered_to       uuid references drivers,   -- driver currently holding the offer
  offer_expires_at timestamptz,
  requested_at     timestamptz not null default now(),
  accepted_at      timestamptz,
  started_at       timestamptz,
  completed_at     timestamptz,
  cancelled_by     uuid references profiles,
  cancel_reason    text
);
create index trips_rider_idx  on trips (rider_id, requested_at desc);
create index trips_driver_idx on trips (driver_id);
create index trips_offer_idx  on trips (offered_to) where status = 'requested';

create table trip_offers (
  id         bigserial primary key,
  trip_id    uuid not null references trips on delete cascade,
  driver_id  uuid not null references drivers,
  offered_at timestamptz not null default now(),
  response   text            -- accepted | rejected | timeout (null = pending)
);

create table ratings (
  trip_id   uuid references trips on delete cascade,
  from_user uuid references profiles,
  to_user   uuid references profiles,
  stars     int not null check (stars between 1 and 5),
  comment   text,
  created_at timestamptz not null default now(),
  primary key (trip_id, from_user)
);

-- Wallet and complaints: tables only in v1 (no app UI yet, see docs/ROADMAP.md)
create table wallets (
  user_id uuid primary key references profiles,
  balance numeric not null default 0
);
create table wallet_transactions (
  id         bigserial primary key,
  user_id    uuid references profiles,
  amount     numeric not null,
  kind       text,          -- topup | trip | refund | payout
  trip_id    uuid references trips,
  created_at timestamptz not null default now()
);
create table complaints (
  id         bigserial primary key,
  trip_id    uuid references trips,
  from_user  uuid references profiles,
  body       text not null,
  status     text not null default 'open',
  created_at timestamptz not null default now()
);

-- Every new auth user gets a rider profile.
create function handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, phone) values (new.id, coalesce(nullif(new.phone, ''), new.id::text));
  insert into wallets (user_id) values (new.id);
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users for each row execute function handle_new_user();
