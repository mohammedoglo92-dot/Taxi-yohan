-- =====================================================================
-- 002: row level security
-- Apps can READ what concerns them. All WRITES go through the functions
-- in 003, so the server stays the single source of truth.
-- =====================================================================
set search_path to public, extensions;

create function is_admin() returns boolean
language sql security definer stable set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'admin');
$$;

alter table profiles            enable row level security;
alter table vehicle_types       enable row level security;
alter table drivers             enable row level security;
alter table trips               enable row level security;
alter table trip_offers         enable row level security;
alter table ratings             enable row level security;
alter table wallets             enable row level security;
alter table wallet_transactions enable row level security;
alter table complaints          enable row level security;

create policy profiles_read  on profiles for select using (id = auth.uid() or is_admin());
create policy vtypes_read    on vehicle_types for select using (true);
create policy vtypes_admin   on vehicle_types for all using (is_admin()) with check (is_admin());

create policy drivers_read on drivers for select using (
  id = auth.uid()
  or is_admin()
  or exists (select 1 from trips t
             where t.driver_id = drivers.id and t.rider_id = auth.uid()
               and t.status in ('accepted','arrived','started'))
);
create policy drivers_admin_update on drivers for update using (is_admin()) with check (is_admin());

create policy trips_read on trips for select using (
  rider_id = auth.uid() or driver_id = auth.uid() or offered_to = auth.uid() or is_admin()
);
create policy offers_read   on trip_offers for select using (driver_id = auth.uid() or is_admin());
create policy ratings_read  on ratings for select using (from_user = auth.uid() or to_user = auth.uid() or is_admin());
create policy wallets_read  on wallets for select using (user_id = auth.uid() or is_admin());
create policy wtx_read      on wallet_transactions for select using (user_id = auth.uid() or is_admin());
create policy complaints_rw on complaints for select using (from_user = auth.uid() or is_admin());
create policy complaints_in on complaints for insert with check (from_user = auth.uid());
create policy complaints_admin_update on complaints for update using (is_admin()) with check (is_admin());

-- Users may only edit their own display name, never their role.
revoke update on profiles from authenticated, anon;
grant  update (full_name) on profiles to authenticated;
create policy profiles_update_own on profiles for update using (id = auth.uid()) with check (id = auth.uid());

-- Realtime: apps subscribe to trip and driver rows (RLS still applies).
alter publication supabase_realtime add table trips, drivers;
