-- =====================================================================
-- 001: schema
-- Tables, enums, generated geography columns, new-user trigger.
-- =====================================================================
create extension if not exists postgis with schema extensions;
set search_path to public, extensions;

create type user_role   as enum ('rider', 'driver', 'admin');
create type trip_status as enum ('requested','accepted','arrived','started','completed','cancelled');
create type pay_method  as enum ('cash', 'wallet');

create table profiles (
  id         uuid primary key references auth.users on delete cascade,
  role       user_role not null default 'rider',
  full_name  text,
  phone      text unique not null,
  created_at timestamptz not null default now()
);

create table vehicle_types (
  id        serial primary key,
  name      text not null,
  base_fare numeric not null,
  per_km    numeric not null,
  per_min   numeric not null,
  min_fare  numeric not null,
  active    boolean not null default true
);

create table drivers (
  id                  uuid primary key references profiles on delete cascade,
  approved            boolean not null default false,
  online              boolean not null default false,
  vehicle_type_id     int references vehicle_types,
  plate               text,
  car_model           text,
  car_color           text,
  lat                 double precision,
  lng                 double precision,
  geom                geography(point, 4326)
    generated always as (st_setsrid(st_makepoint(lng, lat), 4326)::geography) stored,
  location_updated_at timestamptz,
  rating_avg          numeric not null default 5,
  rating_count        int not null default 0
);
create index drivers_geom_idx on drivers using gist (geom);

create table trips (
  id               uuid primary key default gen_random_uuid(),
  rider_id         uuid not null references profiles,
  driver_id        uuid references drivers,
  vehicle_type_id  int references vehicle_types,
  status           trip_status not null default 'requested',
  pickup_lat       double precision not null,
  pickup_lng       double precision not null,
  pickup_address   text,
  drop_lat         double precision not null,
  drop_lng         double precision not null,
  drop_address     text,
  pickup_geom      geography(point, 4326)
    generated always as (st_setsrid(st_makepoint(pickup_lng, pickup_lat), 4326)::geography) stored,
  est_distance_m   int,
  est_duration_s   int,
  est_fare         numeric,
  final_fare       numeric,
  pay_method       pay_method not null default 'cash',
  offered_to       uuid references drivers,   -- driver currently holding the offer
  offer_expires_at timestamptz,
  requested_at     timestamptz not null default now(),
  accepted_at      timestamptz,
  started_at       timestamptz,
  completed_at     timestamptz,
  cancelled_by     uuid references profiles,
  cancel_reason    text
);
create index trips_rider_idx  on trips (rider_id, requested_at desc);
create index trips_driver_idx on trips (driver_id);
create index trips_offer_idx  on trips (offered_to) where status = 'requested';

create table trip_offers (
  id         bigserial primary key,
  trip_id    uuid not null references trips on delete cascade,
  driver_id  uuid not null references drivers,
  offered_at timestamptz not null default now(),
  response   text            -- accepted | rejected | timeout (null = pending)
);

create table ratings (
  trip_id   uuid references trips on delete cascade,
  from_user uuid references profiles,
  to_user   uuid references profiles,
  stars     int not null check (stars between 1 and 5),
  comment   text,
  created_at timestamptz not null default now(),
  primary key (trip_id, from_user)
);

-- Wallet and complaints: tables only in v1 (no app UI yet, see docs/ROADMAP.md)
create table wallets (
  user_id uuid primary key references profiles,
  balance numeric not null default 0
);
create table wallet_transactions (
  id         bigserial primary key,
  user_id    uuid references profiles,
  amount     numeric not null,
  kind       text,          -- topup | trip | refund | payout
  trip_id    uuid references trips,
  created_at timestamptz not null default now()
);
create table complaints (
  id         bigserial primary key,
  trip_id    uuid references trips,
  from_user  uuid references profiles,
  body       text not null,
  status     text not null default 'open',
  created_at timestamptz not null default now()
);

-- Every new auth user gets a rider profile.
create function handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, phone) values (new.id, coalesce(nullif(new.phone, ''), new.id::text));
  insert into wallets (user_id) values (new.id);
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users for each row execute function handle_new_user();
-- =====================================================================
-- 002: row level security
-- Apps can READ what concerns them. All WRITES go through the functions
-- in 003, so the server stays the single source of truth.
-- =====================================================================
set search_path to public, extensions;

create function is_admin() returns boolean
language sql security definer stable set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'admin');
$$;

alter table profiles            enable row level security;
alter table vehicle_types       enable row level security;
alter table drivers             enable row level security;
alter table trips               enable row level security;
alter table trip_offers         enable row level security;
alter table ratings             enable row level security;
alter table wallets             enable row level security;
alter table wallet_transactions enable row level security;
alter table complaints          enable row level security;

create policy profiles_read  on profiles for select using (id = auth.uid() or is_admin());
create policy vtypes_read    on vehicle_types for select using (true);
create policy vtypes_admin   on vehicle_types for all using (is_admin()) with check (is_admin());

create policy drivers_read on drivers for select using (
  id = auth.uid()
  or is_admin()
  or exists (select 1 from trips t
             where t.driver_id = drivers.id and t.rider_id = auth.uid()
               and t.status in ('accepted','arrived','started'))
);
create policy drivers_admin_update on drivers for update using (is_admin()) with check (is_admin());

create policy trips_read on trips for select using (
  rider_id = auth.uid() or driver_id = auth.uid() or offered_to = auth.uid() or is_admin()
);
create policy offers_read   on trip_offers for select using (driver_id = auth.uid() or is_admin());
create policy ratings_read  on ratings for select using (from_user = auth.uid() or to_user = auth.uid() or is_admin());
create policy wallets_read  on wallets for select using (user_id = auth.uid() or is_admin());
create policy wtx_read      on wallet_transactions for select using (user_id = auth.uid() or is_admin());
create policy complaints_rw on complaints for select using (from_user = auth.uid() or is_admin());
create policy complaints_in on complaints for insert with check (from_user = auth.uid());
create policy complaints_admin_update on complaints for update using (is_admin()) with check (is_admin());

-- Users may only edit their own display name, never their role.
revoke update on profiles from authenticated, anon;
grant  update (full_name) on profiles to authenticated;
create policy profiles_update_own on profiles for update using (id = auth.uid()) with check (id = auth.uid());

-- Realtime: apps subscribe to trip and driver rows (RLS still applies).
alter publication supabase_realtime add table trips, drivers;
-- =====================================================================
-- 003: business logic (all security definer, all check auth.uid())
-- =====================================================================
set search_path to public, extensions;

-- ---------- fare ----------------------------------------------------
create function haversine_m(lat1 float8, lng1 float8, lat2 float8, lng2 float8)
returns float8 language sql immutable as $$
  select 2 * 6371000 * asin(sqrt(
    power(sin(radians(lat2 - lat1) / 2), 2) +
    cos(radians(lat1)) * cos(radians(lat2)) * power(sin(radians(lng2 - lng1) / 2), 2)));
$$;

-- Straight line x 1.3 road factor, 25 km/h average city speed.
-- Swap in OSRM/Google here later without touching the apps.
create function estimate_fare(p_plat float8, p_plng float8, p_dlat float8, p_dlng float8, p_vtype int)
returns table (distance_m int, duration_s int, fare numeric)
language plpgsql stable security definer set search_path = public, extensions as $$
declare v vehicle_types; d float8; s float8;
begin
  select * into v from vehicle_types where id = p_vtype and active;
  if not found then raise exception 'unknown_vehicle_type'; end if;
  d := haversine_m(p_plat, p_plng, p_dlat, p_dlng) * 1.3;
  s := d / (25 / 3.6);
  return query select d::int, s::int,
    (round(greatest(v.min_fare, v.base_fare + v.per_km * d / 1000 + v.per_min * s / 60) / 100) * 100)::numeric;
end $$;

-- ---------- dispatch ------------------------------------------------
-- Offers the trip to the nearest eligible driver who has not seen it yet.
-- No driver left -> trip is cancelled with reason 'no_driver'.
create function dispatch_next(p_trip uuid) returns void
language plpgsql security definer set search_path = public, extensions as $$
declare t trips; v_driver uuid;
begin
  select * into t from trips where id = p_trip for update;
  if not found or t.status <> 'requested' then return; end if;

  select d.id into v_driver
  from drivers d
  where d.online and d.approved
    and d.vehicle_type_id = t.vehicle_type_id
    and d.location_updated_at > now() - interval '60 seconds'
    and st_dwithin(d.geom, t.pickup_geom, 5000)
    and not exists (select 1 from trip_offers o where o.trip_id = t.id and o.driver_id = d.id)
    and not exists (select 1 from trips x where x.driver_id = d.id and x.status in ('accepted','arrived','started'))
    and not exists (select 1 from trips y where y.offered_to = d.id and y.status = 'requested' and y.offer_expires_at > now())
  order by d.geom <-> t.pickup_geom
  limit 1;

  if v_driver is null then
    update trips set status = 'cancelled', cancel_reason = 'no_driver', offered_to = null where id = t.id;
    return;
  end if;

  insert into trip_offers (trip_id, driver_id) values (t.id, v_driver);
  update trips set offered_to = v_driver, offer_expires_at = now() + interval '20 seconds' where id = t.id;
end $$;
revoke execute on function dispatch_next(uuid) from public, anon, authenticated;

-- Call every ~10s (see supabase/cron.sql) to move on from silent drivers.
create function expire_offers() returns void
language plpgsql security definer set search_path = public, extensions as $$
declare r record;
begin
  for r in select id, offered_to from trips
           where status = 'requested' and offered_to is not null and offer_expires_at < now() loop
    update trip_offers set response = 'timeout'
      where trip_id = r.id and driver_id = r.offered_to and response is null;
    update trips set offered_to = null where id = r.id;
    perform dispatch_next(r.id);
  end loop;
end $$;
revoke execute on function expire_offers() from public, anon, authenticated;

-- ---------- rider ---------------------------------------------------
create function request_trip(
  p_plat float8, p_plng float8, p_dlat float8, p_dlng float8,
  p_pickup_addr text, p_drop_addr text, p_vtype int)
returns uuid language plpgsql security definer set search_path = public, extensions as $$
declare uid uuid := auth.uid(); e record; v_id uuid;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  if exists (select 1 from trips where rider_id = uid and status in ('requested','accepted','arrived','started')) then
    raise exception 'active_trip_exists';
  end if;
  select * into e from estimate_fare(p_plat, p_plng, p_dlat, p_dlng, p_vtype);
  insert into trips (rider_id, vehicle_type_id, pickup_lat, pickup_lng, pickup_address,
                     drop_lat, drop_lng, drop_address, est_distance_m, est_duration_s, est_fare)
  values (uid, p_vtype, p_plat, p_plng, p_pickup_addr, p_dlat, p_dlng, p_drop_addr,
          e.distance_m, e.duration_s, e.fare)
  returning id into v_id;
  perform dispatch_next(v_id);
  return v_id;
end $$;

create function cancel_trip(p_trip uuid, p_reason text default null) returns void
language plpgsql security definer set search_path = public, extensions as $$
declare uid uuid := auth.uid(); n int;
begin
  update trips set status = 'cancelled', cancelled_by = uid, cancel_reason = coalesce(p_reason, 'user'), offered_to = null
  where id = p_trip and status in ('requested','accepted','arrived')
    and (rider_id = uid or driver_id = uid);
  get diagnostics n = row_count;
  if n = 0 then raise exception 'cannot_cancel'; end if;
end $$;

create function get_trip_driver(p_trip uuid)
returns table (full_name text, phone text, plate text, car_model text, car_color text, rating_avg numeric)
language sql stable security definer set search_path = public, extensions as $$
  select p.full_name, p.phone, d.plate, d.car_model, d.car_color, d.rating_avg
  from trips t join drivers d on d.id = t.driver_id join profiles p on p.id = d.id
  where t.id = p_trip and t.rider_id = auth.uid();
$$;

-- ---------- driver --------------------------------------------------
create function become_driver(p_vtype int, p_plate text, p_model text, p_color text) returns void
language plpgsql security definer set search_path = public, extensions as $$
declare uid uuid := auth.uid();
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  update profiles set role = 'driver' where id = uid and role = 'rider';
  insert into drivers (id, vehicle_type_id, plate, car_model, car_color)
  values (uid, p_vtype, p_plate, p_model, p_color)
  on conflict (id) do update
    set vehicle_type_id = excluded.vehicle_type_id, plate = excluded.plate,
        car_model = excluded.car_model, car_color = excluded.car_color;
end $$;

create function set_online(p_online boolean) returns void
language plpgsql security definer set search_path = public, extensions as $$
begin
  update drivers set online = p_online where id = auth.uid() and approved;
  if not found then raise exception 'driver_not_approved'; end if;
end $$;

create function update_driver_location(p_lat float8, p_lng float8) returns void
language sql security definer set search_path = public, extensions as $$
  update drivers set lat = p_lat, lng = p_lng, location_updated_at = now() where id = auth.uid();
$$;

create function accept_trip(p_trip uuid) returns void
language plpgsql security definer set search_path = public, extensions as $$
declare uid uuid := auth.uid(); n int;
begin
  update trips set driver_id = uid, status = 'accepted', accepted_at = now(), offered_to = null
  where id = p_trip and status = 'requested' and offered_to = uid and offer_expires_at > now();
  get diagnostics n = row_count;
  if n = 0 then raise exception 'offer_expired'; end if;
  update trip_offers set response = 'accepted' where trip_id = p_trip and driver_id = uid and response is null;
end $$;

create function reject_offer(p_trip uuid) returns void
language plpgsql security definer set search_path = public, extensions as $$
declare uid uuid := auth.uid(); n int;
begin
  update trips set offered_to = null where id = p_trip and status = 'requested' and offered_to = uid;
  get diagnostics n = row_count;
  if n = 0 then return; end if;   -- already expired or reassigned: nothing to do
  update trip_offers set response = 'rejected' where trip_id = p_trip and driver_id = uid and response is null;
  perform dispatch_next(p_trip);
end $$;

-- Allowed: accepted -> arrived -> started -> completed (driver of the trip only).
create function set_trip_status(p_trip uuid, p_status trip_status) returns void
language plpgsql security definer set search_path = public, extensions as $$
declare uid uuid := auth.uid(); t trips;
begin
  select * into t from trips where id = p_trip and driver_id = uid for update;
  if not found then raise exception 'not_your_trip'; end if;
  if not ((t.status = 'accepted' and p_status = 'arrived')
       or (t.status = 'arrived'  and p_status = 'started')
       or (t.status = 'started'  and p_status = 'completed')) then
    raise exception 'invalid_transition';
  end if;
  update trips set status = p_status,
    started_at   = case when p_status = 'started'   then now() else started_at end,
    completed_at = case when p_status = 'completed' then now() else completed_at end,
    final_fare   = case when p_status = 'completed' then est_fare else final_fare end
  where id = p_trip;
end $$;

create function get_trip_rider(p_trip uuid)
returns table (full_name text, phone text)
language sql stable security definer set search_path = public, extensions as $$
  select p.full_name, p.phone from trips t join profiles p on p.id = t.rider_id
  where t.id = p_trip and (t.driver_id = auth.uid() or t.offered_to = auth.uid());
$$;

-- ---------- both ----------------------------------------------------
create function rate_trip(p_trip uuid, p_stars int, p_comment text default null) returns void
language plpgsql security definer set search_path = public, extensions as $$
declare uid uuid := auth.uid(); t trips; other uuid;
begin
  select * into t from trips where id = p_trip and status = 'completed' and (rider_id = uid or driver_id = uid);
  if not found then raise exception 'cannot_rate'; end if;
  other := case when t.rider_id = uid then t.driver_id else t.rider_id end;
  insert into ratings (trip_id, from_user, to_user, stars, comment) values (p_trip, uid, other, p_stars, p_comment);
  if other = t.driver_id then
    update drivers set rating_avg = (rating_avg * rating_count + p_stars) / (rating_count + 1),
                       rating_count = rating_count + 1 where id = other;
  end if;
end $$;
-- Example prices in Syrian pounds. Edit freely: this table is the only place fares live.
insert into vehicle_types (name, base_fare, per_km, per_min, min_fare) values
  ('اقتصادي', 5000, 3000, 200, 8000),
  ('مريح',    7000, 4000, 300, 12000),
  ('عائلي',   9000, 5000, 350, 15000);

-- Make yourself admin / approve a driver (run in the SQL editor):
-- update profiles set role = 'admin' where phone = '+963XXXXXXXXX';
-- update drivers  set approved = true where id = (select id from profiles where phone = '+963XXXXXXXXX');
