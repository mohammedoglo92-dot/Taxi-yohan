-- Example prices in Syrian pounds. Edit freely: this table is the only place fares live.
insert into vehicle_types (name, base_fare, per_km, per_min, min_fare) values
  ('اقتصادي', 5000, 3000, 200, 8000),
  ('مريح',    7000, 4000, 300, 12000),
  ('عائلي',   9000, 5000, 350, 15000);

-- Make yourself admin / approve a driver (run in the SQL editor):
-- update profiles set role = 'admin' where phone = '+963XXXXXXXXX';
-- update drivers  set approved = true where id = (select id from profiles where phone = '+963XXXXXXXXX');
