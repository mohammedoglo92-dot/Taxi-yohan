-- Optional but recommended: move to the next driver when one stays silent.
-- Enable the pg_cron extension in Supabase (Database > Extensions), then run:
select cron.schedule('expire-offers', '10 seconds', $$select public.expire_offers()$$);
-- The driver app also rejects automatically at timeout, so the app works without this.
