// Overwritten automatically by the "Admin dashboard" GitHub workflow from your repo secrets.
// For local use, fill these two values (the anon key is public by design).
window.APP_CONFIG = { SUPABASE_URL: "", SUPABASE_ANON_KEY: "" };
