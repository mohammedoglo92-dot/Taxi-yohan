# مرجع الـ API (دوال Supabase RPC)

كلها تتطلب مستخدماً مسجّلاً. تُستدعى بـ `supabase.rpc('name', params: {...})`، والأغلفة الجاهزة في `packages/taxi_core/lib/src/api.dart`.

## الراكب

| الدالة | المعاملات | ترجع | ملاحظات |
| --- | --- | --- | --- |
| `estimate_fare` | `p_plat, p_plng, p_dlat, p_dlng, p_vtype` | `distance_m, duration_s, fare` | تقدير فقط |
| `request_trip` | نفس السابقة + `p_pickup_addr, p_drop_addr` | `uuid` الرحلة | خطأ `active_trip_exists` إن كان عنده رحلة جارية |
| `cancel_trip` | `p_trip, p_reason?` | - | للراكب أو السائق، قبل بدء الرحلة فقط |
| `get_trip_driver` | `p_trip` | الاسم، الهاتف، اللوحة، الطراز، اللون، التقييم | لراكب الرحلة فقط |
| `rate_trip` | `p_trip, p_stars (1-5), p_comment?` | - | بعد اكتمال الرحلة، مرة واحدة لكل طرف |

## السائق

| الدالة | المعاملات | ملاحظات |
| --- | --- | --- |
| `become_driver` | `p_vtype, p_plate, p_model, p_color` | ينشئ طلب سائق (غير موافَق عليه) |
| `set_online` | `p_online` | خطأ `driver_not_approved` قبل الموافقة |
| `update_driver_location` | `p_lat, p_lng` | يُستدعى كل ~10 م وكل 15 ثانية |
| `accept_trip` | `p_trip` | خطأ `offer_expired` إن انتهت المهلة أو أُعيد العرض |
| `reject_offer` | `p_trip` | ينتقل للسائق التالي |
| `set_trip_status` | `p_trip, p_status` | `arrived`, `started`, `completed` بالترتيب فقط |
| `get_trip_rider` | `p_trip` | اسم الراكب وهاتفه |

## داخلية (غير متاحة للتطبيقات)
`dispatch_next(p_trip)`, `expire_offers()`

## التدفقات اللحظية (Realtime streams)
- `trips` مفلتر بـ `id` (الراكب) أو `offered_to` أو `driver_id` (السائق)
- `drivers` مفلتر بـ `id` (موقع السائق للراكب أثناء الرحلة)

## رموز الأخطاء الشائعة
`not_authenticated`, `active_trip_exists`, `unknown_vehicle_type`, `cannot_cancel`, `offer_expired`, `not_your_trip`, `invalid_transition`, `cannot_rate`, `driver_not_approved`
