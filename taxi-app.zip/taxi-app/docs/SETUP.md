# دليل الإعداد (من الصفر إلى تطبيق شغّال على GitHub)

كل شي هنا مرتب بالترتيب. الوقت المتوقع: 30 إلى 45 دقيقة.

## 1. قاعدة البيانات (Supabase)

1. أنشئ مشروعاً على [supabase.com](https://supabase.com).
2. افتح **SQL Editor**، الصق محتوى الملف **`supabase/setup_all.sql`** كاملاً، واضغط Run.
   (هو دمج للملفات الثلاثة في `supabase/migrations` مع `seed.sql`، فشغّله **مرة واحدة فقط**.)
3. (موصى به) Database > Extensions: فعّل **pg_cron**، ثم شغّل `supabase/cron.sql` في SQL Editor.
   بدونه يبقى النظام شغالاً، لكن إن أُغلق تطبيق سائق فجأة يتأخر الانتقال للسائق التالي.

## 2. تسجيل الدخول بالهاتف

Authentication > Providers > **Phone**: فعّله واختر مزوّد SMS (مثل Twilio) وأدخل مفاتيحه.

- للتجربة بدون SMS: في نفس الصفحة أضف **Test phone numbers** (رقم ورمز ثابت).
- تأكد أن المزوّد يدعم الأرقام السورية (+963) قبل الإطلاق. إن لم يدعمها ستحتاج بوابة SMS محلية.

## 3. أول أدمن

سجّل دخولاً من أي تطبيق برقمك مرة (أو من لوحة الإدارة)، ثم في SQL Editor:
```sql
update profiles set role = 'admin' where phone = '+963XXXXXXXXX';
```

## 4. ارفع المشروع على GitHub

1. أنشئ مستودعاً جديداً (فارغاً) على GitHub.
2. فك الـ ZIP وارفع كل الملفات (أو `git init && git add . && git commit -m init && git remote add origin ... && git push -u origin main`).
   تأكد أن مجلد `.github` رُفع (هو مخفي في بعض الأنظمة).
3. أضف مفاتيح Supabase: Settings > Secrets and variables > Actions > **New repository secret**:
   - `SUPABASE_URL`: من Supabase، Project Settings > API > Project URL
   - `SUPABASE_ANON_KEY`: نفس الصفحة، مفتاح `anon public`

   لا تضع مفتاح `service_role` في أي مكان.

## 5. ما يسويه GitHub لك تلقائياً

عند كل push:

| Workflow | ماذا يفعل |
| --- | --- |
| **CI** (`ci.yml`) | يفحص الكود (`flutter analyze`) ويشغّل الاختبارات، ثم **يبني ملفي APK** (الراكب والسائق) ويرفعهما كـ artifacts |
| **Admin dashboard** (`admin-pages.yml`) | ينشر لوحة الإدارة على GitHub Pages |

**نشر لوحة الإدارة**: Settings > Pages > Source: **GitHub Actions**. بعد أول تشغيل ناجح يظهر الرابط في Actions وفي صفحة Pages. أنشر مجدداً من Actions > Admin dashboard > Run workflow.

**تنزيل التطبيقين**: تبويب **Actions** > آخر تشغيل لـ CI > أسفل الصفحة **Artifacts** > `taxi-rider-apk` و`taxi-driver-apk`. ثبّتهما على هاتف أندرويد.

> **إذا ظهر خطأ أحمر في CI**: افتح التشغيل، انسخ نص الخطأ، وأرسله لي لأصلحه. هذه هي نقطة الفحص الفعلية للكود.

## 6. التجربة الكاملة

1. ثبّت **تطبيق السائق**، سجّل برقم، أدخل بيانات السيارة.
2. من **لوحة الإدارة** > السائقون: اضغط **موافقة**.
3. في تطبيق السائق: **تحديث الحالة**، ثم فعّل **متصل**.
4. ثبّت **تطبيق الراكب** على هاتف آخر (برقم آخر)، اضغط وجهتك على الخريطة، **اطلب الآن**.
5. يظهر العرض عند السائق: قبول > وصلت > بدء > إنهاء. ثم التقييم.

## 7. التشغيل المحلي (اختياري)

```
./scripts/bootstrap.sh com.yourcompany          # يولّد android/ios ويضيف الصلاحيات
cd apps/rider
flutter run --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...
```
تأكد بعد `bootstrap` أن `git status` لا يُظهر تغييراً في `lib/` أو `pubspec.yaml`.

## 8. قبل النشر على المتاجر

- **الاسم والحزمة**: غيّر `appName` في `packages/taxi_core/lib/src/config.dart`، وشغّل `bootstrap` بـ org الخاص بك. غيّر `userAgentPackageName` في ملفات الخرائط (حالياً `com.example.*`).
- **التوقيع**: الـ APK الذي يبنيه CI موقّع بمفتاح التطوير، وصالح للتجربة فقط. للمتجر أنشئ keystore خاص بك وأضفه كـ secrets واضبط `build.gradle`. لا ترفع `key.properties` أبداً.
- **الخرائط**: خوادم `tile.openstreetmap.org` العامة للتطوير فقط. استخدم خادم بلاطات خاصاً أو مزوّداً (MapTiler، Stadia...) وغيّر `urlTemplate` في ملفات الخرائط الأربعة.
- **iOS**: يحتاج Mac و Xcode وحساب Apple Developer. التطبيق يولّد مجلد ios، لكن CI يبني أندرويد فقط.
- **سياسة الخصوصية وشروط الاستخدام**: مطلوبة من المتاجر لأن التطبيقات تجمع الموقع ورقم الهاتف.
