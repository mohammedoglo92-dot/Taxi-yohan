import 'package:supabase_flutter/supabase_flutter.dart';

/// Single place for branding and settings. Change [appName] to your brand.
/// Supabase keys are passed at build time, never committed:
///   flutter run --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...
class AppConfig {
  static const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
  static const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

  static const appName = 'تاكسي'; // TODO: your brand name
  static const currency = 'ل.س';

  /// Map starts here until GPS answers (Damascus).
  static const defaultLat = 33.5138;
  static const defaultLng = 36.2765;

  /// Must match the interval in supabase/migrations/..._functions.sql (dispatch_next).
  static const offerSeconds = 20;

  static Future<void> init() async {
    assert(supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty,
        'Pass SUPABASE_URL and SUPABASE_ANON_KEY with --dart-define');
    await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  }
}
