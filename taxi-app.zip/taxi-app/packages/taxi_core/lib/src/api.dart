import 'package:supabase_flutter/supabase_flutter.dart';
import 'models.dart';

/// Thin wrapper over Supabase. Reads are table queries/streams (protected by
/// RLS), writes are RPC calls into the SQL functions (see supabase/migrations).
class Api {
  static SupabaseClient get _sb => Supabase.instance.client;
  static String get uid => _sb.auth.currentUser!.id;
  static const _active = ['requested', 'accepted', 'arrived', 'started'];

  // ---------------- auth / profile ----------------
  /// "0933123456", "933123456", "00963933123456" -> "+963933123456".
  static String normalizePhone(String raw) {
    var p = raw.replaceAll(RegExp(r'[\s\-()]'), '');
    if (p.startsWith('+')) return p;
    if (p.startsWith('00')) return '+${p.substring(2)}';
    if (p.startsWith('0')) return '+963${p.substring(1)}';
    return '+963$p';
  }

  static Future<void> sendOtp(String phone) => _sb.auth.signInWithOtp(phone: normalizePhone(phone));

  static Future<void> verifyOtp(String phone, String code) =>
      _sb.auth.verifyOTP(phone: normalizePhone(phone), token: code, type: OtpType.sms);

  static Future<void> signOut() => _sb.auth.signOut();

  static Future<String?> myName() async {
    final r = await _sb.from('profiles').select('full_name').eq('id', uid).single();
    return r['full_name'] as String?;
  }

  static Future<void> setMyName(String name) =>
      _sb.from('profiles').update({'full_name': name}).eq('id', uid);

  static Future<List<VehicleType>> vehicleTypes() async {
    final r = await _sb.from('vehicle_types').select('id,name').eq('active', true).order('id');
    return r.map<VehicleType>((m) => VehicleType.fromMap(m)).toList();
  }

  // ---------------- rider ----------------
  static Future<FareEstimate> estimate(
      double plat, double plng, double dlat, double dlng, int vtype) async {
    final r = await _sb.rpc('estimate_fare', params: {
      'p_plat': plat, 'p_plng': plng, 'p_dlat': dlat, 'p_dlng': dlng, 'p_vtype': vtype,
    }) as List;
    return FareEstimate.fromMap(Map<String, dynamic>.from(r.first as Map));
  }

  static Future<String> requestTrip({
    required double plat, required double plng,
    required double dlat, required double dlng,
    required int vtype,
    String pickupAddress = 'موقعي الحالي',
    String dropAddress = 'الوجهة على الخريطة',
  }) async {
    final id = await _sb.rpc('request_trip', params: {
      'p_plat': plat, 'p_plng': plng, 'p_dlat': dlat, 'p_dlng': dlng,
      'p_pickup_addr': pickupAddress, 'p_drop_addr': dropAddress, 'p_vtype': vtype,
    });
    return id as String;
  }

  static Future<void> cancelTrip(String id, {String? reason}) =>
      _sb.rpc('cancel_trip', params: {'p_trip': id, 'p_reason': reason});

  static Future<void> rateTrip(String id, int stars, {String? comment}) =>
      _sb.rpc('rate_trip', params: {'p_trip': id, 'p_stars': stars, 'p_comment': comment});

  static Future<Trip?> activeRiderTrip() async {
    final r = await _sb
        .from('trips')
        .select()
        .eq('rider_id', uid)
        .inFilter('status', _active)
        .order('requested_at', ascending: false)
        .limit(1);
    return r.isEmpty ? null : Trip.fromMap(r.first);
  }

  static Future<List<Trip>> myTrips() async {
    final r = await _sb
        .from('trips')
        .select()
        .or('rider_id.eq.$uid,driver_id.eq.$uid')
        .order('requested_at', ascending: false)
        .limit(50);
    return r.map<Trip>((m) => Trip.fromMap(m)).toList();
  }

  static Stream<Trip> tripStream(String id) => _sb
      .from('trips')
      .stream(primaryKey: ['id'])
      .eq('id', id)
      .where((l) => l.isNotEmpty)
      .map((l) => Trip.fromMap(l.first));

  static Future<DriverInfo?> driverInfo(String tripId) async {
    final r = await _sb.rpc('get_trip_driver', params: {'p_trip': tripId}) as List;
    return r.isEmpty ? null : DriverInfo.fromMap(Map<String, dynamic>.from(r.first as Map));
  }

  /// Live driver position for the rider (RLS only allows it during an active trip).
  static Stream<DriverProfile> driverStream(String driverId) => _sb
      .from('drivers')
      .stream(primaryKey: ['id'])
      .eq('id', driverId)
      .where((l) => l.isNotEmpty)
      .map((l) => DriverProfile.fromMap(l.first));

  // ---------------- driver ----------------
  static Future<DriverProfile?> myDriver() async {
    final r = await _sb.from('drivers').select().eq('id', uid).maybeSingle();
    return r == null ? null : DriverProfile.fromMap(r);
  }

  static Future<void> becomeDriver(int vtype, String plate, String model, String color) =>
      _sb.rpc('become_driver', params: {
        'p_vtype': vtype, 'p_plate': plate, 'p_model': model, 'p_color': color,
      });

  static Future<void> setOnline(bool online) => _sb.rpc('set_online', params: {'p_online': online});

  static Future<void> updateLocation(double lat, double lng) =>
      _sb.rpc('update_driver_location', params: {'p_lat': lat, 'p_lng': lng});

  /// Trips currently offered to this driver.
  static Stream<List<Trip>> offersStream() => _sb
      .from('trips')
      .stream(primaryKey: ['id'])
      .eq('offered_to', uid)
      .map((l) => l.map(Trip.fromMap).toList());

  /// Trips assigned to this driver (filter to active ones in the UI).
  static Stream<List<Trip>> driverTripsStream() => _sb
      .from('trips')
      .stream(primaryKey: ['id'])
      .eq('driver_id', uid)
      .map((l) => l.map(Trip.fromMap).toList());

  static Future<void> acceptTrip(String id) => _sb.rpc('accept_trip', params: {'p_trip': id});
  static Future<void> rejectOffer(String id) => _sb.rpc('reject_offer', params: {'p_trip': id});
  static Future<void> setTripStatus(String id, TripStatus s) =>
      _sb.rpc('set_trip_status', params: {'p_trip': id, 'p_status': s.name});

  static Future<RiderInfo?> riderInfo(String tripId) async {
    final r = await _sb.rpc('get_trip_rider', params: {'p_trip': tripId}) as List;
    return r.isEmpty ? null : RiderInfo.fromMap(Map<String, dynamic>.from(r.first as Map));
  }
}
