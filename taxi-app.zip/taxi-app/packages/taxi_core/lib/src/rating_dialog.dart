import 'package:flutter/material.dart';
import 'api.dart';

/// Asks for 1-5 stars and sends it. Returns when the dialog closes.
Future<void> showRatingDialog(BuildContext context, String tripId, {String title = 'قيّم الرحلة'}) {
  int stars = 5;
  return showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setState) => AlertDialog(
        title: Text(title),
        content: Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(
            5,
            (i) => IconButton(
              icon: Icon(i < stars ? Icons.star : Icons.star_border, color: Colors.amber, size: 32),
              onPressed: () => setState(() => stars = i + 1),
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('تخطي')),
          FilledButton(
            onPressed: () async {
              try {
                await Api.rateTrip(tripId, stars);
              } catch (_) {}
              if (ctx.mounted) Navigator.pop(ctx);
            },
            child: const Text('إرسال'),
          ),
        ],
      ),
    ),
  );
}
