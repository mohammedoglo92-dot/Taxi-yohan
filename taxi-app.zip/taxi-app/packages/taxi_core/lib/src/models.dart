enum TripStatus { requested, accepted, arrived, started, completed, cancelled }

TripStatus _status(String s) =>
    TripStatus.values.firstWhere((e) => e.name == s, orElse: () => TripStatus.requested);

double _d(dynamic v) => (v as num).toDouble();
double? _dn(dynamic v) => v == null ? null : (v as num).toDouble();

extension TripStatusX on TripStatus {
  bool get isActive =>
      this == TripStatus.requested ||
      this == TripStatus.accepted ||
      this == TripStatus.arrived ||
      this == TripStatus.started;

  String get labelAr => switch (this) {
        TripStatus.requested => 'جاري البحث عن سائق...',
        TripStatus.accepted => 'السائق في الطريق إليك',
        TripStatus.arrived => 'السائق وصل',
        TripStatus.started => 'الرحلة جارية',
        TripStatus.completed => 'انتهت الرحلة',
        TripStatus.cancelled => 'ملغية',
      };
}

class VehicleType {
  final int id;
  final String name;
  VehicleType(this.id, this.name);
  factory VehicleType.fromMap(Map<String, dynamic> m) => VehicleType(m['id'] as int, m['name'] as String);
}

class FareEstimate {
  final int distanceM;
  final int durationS;
  final double fare;
  FareEstimate(this.distanceM, this.durationS, this.fare);
  factory FareEstimate.fromMap(Map<String, dynamic> m) =>
      FareEstimate(m['distance_m'] as int, m['duration_s'] as int, _d(m['fare']));
}

class Trip {
  final String id;
  final String riderId;
  final String? driverId;
  final String? offeredTo;
  final DateTime? offerExpiresAt;
  final TripStatus status;
  final double pickupLat, pickupLng, dropLat, dropLng;
  final String? pickupAddress, dropAddress, cancelReason;
  final int? estDistanceM, estDurationS;
  final double? estFare, finalFare;
  final DateTime requestedAt;

  Trip({
    required this.id,
    required this.riderId,
    this.driverId,
    this.offeredTo,
    this.offerExpiresAt,
    required this.status,
    required this.pickupLat,
    required this.pickupLng,
    required this.dropLat,
    required this.dropLng,
    this.pickupAddress,
    this.dropAddress,
    this.cancelReason,
    this.estDistanceM,
    this.estDurationS,
    this.estFare,
    this.finalFare,
    required this.requestedAt,
  });

  factory Trip.fromMap(Map<String, dynamic> m) => Trip(
        id: m['id'] as String,
        riderId: m['rider_id'] as String,
        driverId: m['driver_id'] as String?,
        offeredTo: m['offered_to'] as String?,
        offerExpiresAt:
            m['offer_expires_at'] == null ? null : DateTime.parse(m['offer_expires_at'] as String).toLocal(),
        status: _status(m['status'] as String),
        pickupLat: _d(m['pickup_lat']),
        pickupLng: _d(m['pickup_lng']),
        dropLat: _d(m['drop_lat']),
        dropLng: _d(m['drop_lng']),
        pickupAddress: m['pickup_address'] as String?,
        dropAddress: m['drop_address'] as String?,
        cancelReason: m['cancel_reason'] as String?,
        estDistanceM: m['est_distance_m'] as int?,
        estDurationS: m['est_duration_s'] as int?,
        estFare: _dn(m['est_fare']),
        finalFare: _dn(m['final_fare']),
        requestedAt: DateTime.parse(m['requested_at'] as String).toLocal(),
      );
}

class DriverProfile {
  final String id;
  final bool approved, online;
  final int? vehicleTypeId;
  final double? lat, lng;
  DriverProfile(this.id, this.approved, this.online, this.vehicleTypeId, this.lat, this.lng);
  factory DriverProfile.fromMap(Map<String, dynamic> m) => DriverProfile(
        m['id'] as String,
        m['approved'] as bool,
        m['online'] as bool,
        m['vehicle_type_id'] as int?,
        _dn(m['lat']),
        _dn(m['lng']),
      );
}

/// Driver details shown to the rider.
class DriverInfo {
  final String? name, phone, plate, carModel, carColor;
  final double rating;
  DriverInfo(this.name, this.phone, this.plate, this.carModel, this.carColor, this.rating);
  factory DriverInfo.fromMap(Map<String, dynamic> m) => DriverInfo(
        m['full_name'] as String?,
        m['phone'] as String?,
        m['plate'] as String?,
        m['car_model'] as String?,
        m['car_color'] as String?,
        _d(m['rating_avg']),
      );
}

/// Rider details shown to the driver.
class RiderInfo {
  final String? name, phone;
  RiderInfo(this.name, this.phone);
  factory RiderInfo.fromMap(Map<String, dynamic> m) =>
      RiderInfo(m['full_name'] as String?, m['phone'] as String?);
}
