import 'package:flutter_test/flutter_test.dart';
import 'package:taxi_core/taxi_core.dart';

void main() {
  group('Api.normalizePhone', () {
    test('local number with leading zero', () {
      expect(Api.normalizePhone('0933123456'), '+963933123456');
    });
    test('local number without zero', () {
      expect(Api.normalizePhone('933123456'), '+963933123456');
    });
    test('00 international prefix', () {
      expect(Api.normalizePhone('00963933123456'), '+963933123456');
    });
    test('already international', () {
      expect(Api.normalizePhone('+963933123456'), '+963933123456');
    });
    test('strips spaces and dashes', () {
      expect(Api.normalizePhone('093 312-3456'), '+963933123456');
    });
  });

  group('TripStatus', () {
    test('active statuses', () {
      expect(TripStatus.requested.isActive, true);
      expect(TripStatus.started.isActive, true);
      expect(TripStatus.completed.isActive, false);
      expect(TripStatus.cancelled.isActive, false);
    });
    test('Trip.fromMap parses a row', () {
      final t = Trip.fromMap({
        'id': 'a', 'rider_id': 'r', 'driver_id': null, 'offered_to': null,
        'offer_expires_at': null, 'status': 'accepted',
        'pickup_lat': 33.5, 'pickup_lng': 36.3, 'drop_lat': 33.6, 'drop_lng': 36.4,
        'est_fare': 12000, 'est_distance_m': 5000, 'est_duration_s': 600,
        'requested_at': '2026-11-08T10:00:00Z',
      });
      expect(t.status, TripStatus.accepted);
      expect(t.estFare, 12000.0);
    });
  });
}
