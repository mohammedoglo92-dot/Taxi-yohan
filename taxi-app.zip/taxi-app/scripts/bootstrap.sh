#!/usr/bin/env bash
# Generates android/ios folders for the apps, adds permissions, fetches packages.
# Usage: ./scripts/bootstrap.sh [org] [rider] [driver]
#   ./scripts/bootstrap.sh com.yourcompany            -> both apps
#   ./scripts/bootstrap.sh com.yourcompany rider      -> only rider
set -euo pipefail
cd "$(dirname "$0")/.."
ORG="${1:-com.example}"
shift || true
APPS=("$@")
[ ${#APPS[@]} -eq 0 ] && APPS=(rider driver)
for app in "${APPS[@]}"; do
  (cd "apps/$app" && flutter create --project-name "taxi_$app" --org "$ORG" --platforms android,ios . && flutter pub get)
  rm -f "apps/$app/test/widget_test.dart"
  python3 scripts/patch_platforms.py "apps/$app"
done
echo "Done."
